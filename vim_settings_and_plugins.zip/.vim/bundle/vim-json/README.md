Syntax highlighting for JSON in Vim
-----------------------------------

Pathogen-friendly packaging of `vim-json` <sup>[1](#source)</sup> originally written by 
Jeroen Ruigrok van der Werven.

Install
-------

In your bundle directory, clone this repo:

    % git clone git@github.com:leshill/vim-json.git

Source your `.vimrc` or (re-)start Vim.

Maintainer
----------

Les Hill [@leshill](https://twitter.com/leshill)

#### Source
Original script [here](http://www.vim.org/scripts/script.php?script_id=1945).
